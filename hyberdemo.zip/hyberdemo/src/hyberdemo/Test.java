package hyberdemo;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;

public class Test {
	public static void main(String args[]) {
		Configuration cfg = new Configuration();
		cfg.configure();//to load configuration file

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();
		// dml
		//insert the data into the data database//
	/*Transaction tran = session.beginTransaction();
Employee emp = new Employee();
emp.setEid(1);
emp.setEname("krishna");
emp.setEsal(700000);
System.out.println(emp);


		//Employee emp=session.get(Employee.class,1);
		session.save(emp);//insert,ORM

		tran.commit();
/*Employee emp=(Employee) session.get(Employee.class,new Integer(1));
System.out.println("id"+emp.getEid());*/
		
		//update the data in the table form//
//		Transaction tran = session.beginTransaction();
//		Object o=(Employee) session.get(Employee.class,new Integer(1));
//		Employee e=(Employee) o;
//		e.setEname("babu");
//		e.setEsal(40000);
//		session.update(o);
//		System.out.println(e);
//		
//		factory.close();
//		tran.commit();
//		session.close();
		//delete the data from the data//
		Transaction tran = session.beginTransaction();
		Object obj=(Employee) session.get(Employee.class,new Integer(1));
		Employee e=(Employee) obj;
		session.delete(obj);
		//System.out.println(e);
		
		factory.close();
		tran.commit();
		session.close();
    }

}
